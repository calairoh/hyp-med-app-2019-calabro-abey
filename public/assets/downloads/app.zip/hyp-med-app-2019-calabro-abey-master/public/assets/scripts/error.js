$(document).ready(function(){
    setTimeout(function() {
        location.href = "/";
    }, 5000);
});